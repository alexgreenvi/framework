<footer>
</footer>

<!-- Libs JS Files -->
<script type="text/javascript" src="/assets/js/libs/jquery.min.js"></script>
<script type="text/javascript" src="/assets/js/libs/slick.js"></script>
<script type="text/javascript" src="/assets/js/libs/fancybox/fancybox.min.js"></script>

<!-- Core JS Files -->
<script type="text/javascript" src="/assets/js/admin-scripts.min.js"></script>
<script type="text/javascript" src="/assets/js/admin-main.min.js"></script>

</body>
</html>
