<?
/**
 *
 * @arParam массив праметров компонента
 * @arResult массив результата
 * @arItem массив отдельного элемента
 *
 */
if(!sizeof($arResult)) {
    echo '<br><p style="text-align: center; color: #5d5f63;">Нет материалов, доступных для отображения</p>';
}