$(function () {
    // AjaxForm.init();
    AjaxForm.init();
});